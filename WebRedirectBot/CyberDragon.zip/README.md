# Cyber Dragon Web Portal 🐉

A stylish, cyber-themed web portal launcher with a cool dragon interface!

## Features
- 23 Popular Websites Ready to Access
- Cool Animated Dragon ASCII Art
- Hacker-Style Interface
- Easy Navigation with Numbered Options
- Smooth Animations and Color Effects
- Professional Terminal Experience

## Requirements
- Java Runtime Environment (JRE) 8 or higher
- Linux/Mac OS Terminal (For Windows, use Git Bash or WSL)

## Quick Start
1. Download and extract `CyberDragon.zip`
2. Make the launcher executable (one-time setup):
   ```bash
   chmod +x launch.sh
   ```
3. Run the program:
   - Double-click `launch.sh` and select "Run in Terminal"
   OR
   - Open terminal and run: `./launch.sh`
   OR
   - Direct JAR execution: `java -jar WebRedirectBot.jar`

## Available Portals
1. Google Search
2. YouTube
3. GitHub
4. LinkedIn
5. Twitter
6. Facebook
7. Reddit
8. Stack Overflow
9. Amazon
10. Netflix
11. Spotify
12. Microsoft Office
13. Coursera
14. Wikipedia
15. ChatGPT
16. Medium
17. Discord
18. Trello
19. Canva
20. Gmail
21. WhatsApp Web
22. Twitch
23. CodePen

## Usage Tips
- Use numbers 1-23 to select websites
- Press Enter after visiting a site to return to menu
- Use Ctrl+C anytime to exit
- Enjoy the cool cyber aesthetic! 🚀

## Developer
Created by Dip Saha
Version: 0.0.1

## Note
This is a proprietary software. The source code is encrypted for protection.
All rights reserved © 2024
