WebRedirectBot.clas#!/bin/bash
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

if ! command -v java &> /dev/null; then
    echo -e "${RED}[!] Java is not installed!${NC}"
    echo -e "${RED}[!] Please install Java to run this program.${NC}"
    read -p "Press Enter to exit..."
    exit 1
fi

echo -e "${GREEN}[*] Launching Cyber Dragon Bot...${NC}"
java -jar WebRedirectBot.jar
